define([
  './alert_srv',
  './util_srv',
  './datasource_srv',
  './context_srv',
  './timer',
  './keyboard_manager',
  './analytics',
  './popover_srv',
  './segment_srv',
  './backend_srv',
  './dynamic_directive_srv',
],
function () {});
