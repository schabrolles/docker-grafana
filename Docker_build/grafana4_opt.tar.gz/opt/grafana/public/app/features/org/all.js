define([
  './org_users_ctrl',
  './profile_ctrl',
  './org_users_ctrl',
  './select_org_ctrl',
  './change_password_ctrl',
  './newOrgCtrl',
  './userInviteCtrl',
  './orgApiKeysCtrl',
  './orgDetailsCtrl',
  './prefs_control',
], function () {});
