define([
  './playlists_ctrl',
  './playlist_search',
  './playlist_srv',
  './playlist_edit_ctrl',
  './playlist_routes'
], function () {});
