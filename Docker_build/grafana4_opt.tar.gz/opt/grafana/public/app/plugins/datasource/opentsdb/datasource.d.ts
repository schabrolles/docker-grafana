declare var OpenTsDatasource: any;
export {OpenTsDatasource};

